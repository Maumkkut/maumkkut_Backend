"""
OpenStack
---------

The package to support OpenStack templates using troposphere.
"""
